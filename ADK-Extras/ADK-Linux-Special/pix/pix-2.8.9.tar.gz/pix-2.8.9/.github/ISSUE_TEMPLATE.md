
```
 * Pix version (pix --version)
 * Distribution - (Mint 17.2, Arch, Fedora 25, etc...)
```

**Issue**



**Steps to reproduce**



**Expected behaviour**



**Other information**
