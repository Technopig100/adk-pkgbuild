# ADK-Linux min desktop theme settings for plasma.

![view](View-1.png?raw=true)