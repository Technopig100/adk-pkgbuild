## ADK-Linux iso (Branding) files

![view](View-1.png?raw=true)